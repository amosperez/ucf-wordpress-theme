<?php get_header(); ?>

    <div class="container">

        <!-- <h1><?php the_title();?></h1> -->

        <!-- <?php get_template_part('includes/section', 'content'); ?> -->
    </div>


    <div class="container mt-10">
    <div class="row">
        <div class="col">            
            <!-- <p class="display-4 font-weight-black pr-5">We empower students to <span class="heavy-underline">connect, engage, and create a positive impact</span> on campus life.</p> -->
            <p class="h1 font-weight-black pr-5">We empower students to <span class="heavy-underline">connect</span>, <span class="heavy-underline">involve</span>  themselves, and create a positive <span class="heavy-underline">impact</span> on campus life.</p>

        </div>
        <div class="col pr-5">            
            <!-- <p class="display-4 font-weight-black pr-5">We empower students to <span class="heavy-underline">connect, engage, and create a positive impact</span> on campus life.</p> -->
            <p class="display-4 font-weight-black pr-5">We empower students to <span class="heavy-underline">connect</span>, <span class="heavy-underline">involve</span>  themselves, and create a positive <span class="heavy-underline">impact</span> on campus life.</p>

        </div>
    </div>
    </div>

    <div class="mt-10 bg-primary py-10">
        <div class="container">
        <div class="pr-5">            
        <p class="display-4 font-weight-black pr-5">We empower students to <span class="heavy-underline">connect</span>, <span class="heavy-underline">involve</span>  themselves, and create a positive <span class="heavy-underline">impact</span> on campus life.</p>
        </div>
        </div>
    </div>

    <div class="bg-inverse py-10">
        <div class="container">
        <div class="pr-5">            
        <p class="display-4 font-weight-black pr-5 text-primary">We empower students to <span class="text-white">connect</span>, <span class="text-white">involve</span>  themselves, and create a positive <span class="text-white">impact</span> on campus life.</p>

        <!-- <p class="display-4 font-weight-black pr-5 text-primary">We empower students to <span class="">connect, engage, and create a positive impact</span> on campus life.</p> -->
        </div>
        </div>
    </div>

    
<?php get_footer(); ?>

